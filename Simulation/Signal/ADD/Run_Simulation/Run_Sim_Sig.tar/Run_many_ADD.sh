SCRATCH_SRC=/home/orion/Project/ParticlePhysics/FCC/Simulation/Signal/ADD/Processes
DATA=/home/orion/Project/ParticlePhysics/FCC/Simulation/Data/FCC_Project/Signal/ADD
./Run_Processes_bash.sh 4 17000 10000 1 
./Run_Processes_bash.sh 4 18000 10000 1 
./Run_Processes_bash.sh 4 19000 10000 1 
./Run_Processes_bash.sh 4 20000 10000 1 
echo Waiting ...................................... 
