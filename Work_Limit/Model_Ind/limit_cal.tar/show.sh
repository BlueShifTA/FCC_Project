#acc=(68 95 192 238 262 230)


#acc=( 203 243)
#acc=( 232 248)
acc=( 271 )
for i in "${acc[@]}" 
do
		more limit_${i}.txt | grep expected | sed s/" sig"/sig/g | awk '{print $4}'
done
