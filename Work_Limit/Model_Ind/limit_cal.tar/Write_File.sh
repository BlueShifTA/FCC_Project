#!/bin/bash

FILENAME=Run_many_limit.sh

for i in `seq 5 5 30`
do
		echo "./run_limit.sh ${i} > limit_${i}.txt &" >> ${FILENAME}
done

chmod a+x ${FILENAME}
