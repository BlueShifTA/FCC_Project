#!/bin/bash
# INPUT1 as Error
source lxplus_standalone_setup.sh

error=${1}

root -l <<EOF
    .L roostats_cl95.C 
    error=${error}/100.
    roostats_limit(1000000,50000,1.0,0.0,1156650,1156650.*error,1156650,false,1,"cls","",time(NULL))
EOF
